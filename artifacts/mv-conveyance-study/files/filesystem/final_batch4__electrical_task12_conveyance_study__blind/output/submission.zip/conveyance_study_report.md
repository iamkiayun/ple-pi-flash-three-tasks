# Pacific Crest Space Force Annex — 13.8 kV Conveyance Study Report
Solicitation FA4610-26-R-0031 | Project PCSFA 24-0117

## Executive Summary
This conveyance study evaluates medium-voltage (13.8 kV) conveyance alternatives for seven distribution circuits (C01 through C07) at Pacific Crest Space Force Annex, Los Angeles County, California. The evaluation assesses compliance with governing criteria (UFC 3-550-01, UFC 3-501-01, PCSFA-IEDS Rev 3, NFPA 70) and cost-effectiveness based on UFC 3-740-05 and the RFP estimating basis.

## Evaluated Conveyance Types and Items
- Site Items (C01, C02, C03, C04, C06, C07): CEDB (Concrete-Encased Ductbank), UEDB (Unencased Ductbank), DBC (Direct-Buried Cable), HDD (Horizontal Directional Drilling), OH (Overhead Pole Line).
- Building Item (C05): RMC (Rigid Metal Conduit), EMT (Electrical Metallic Tubing), TRAY-EN (Fully Enclosed Solid-Bottom Cable Tray), TRAY-LD (Ladder Cable Tray).

## Summary of Recommendations
- **C01 (SS1-F1 to MB1-ERA)**: CEDB recommended. Essential mission feeder to MB-1 MSG-A.
- **C02 (SS1-F2 to MB1-ERB)**: CEDB recommended. Dual feeder to MB-1 MSG-B.
- **C03 (SS1-F3 to CUP1-S)**: CEDB recommended. Primary service to Central Utility Plant SWG-C1.
- **C04 (CUP1-E to TX-LS2)**: CEDB recommended. Service to Lift Station 2 pad-mounted transformer.
- **C05 (MSG-A to USS-A1)**: RMC recommended. Indoor feeder routed in designated utility corridor.
- **C06 (SS1-F4 to TX-GH1)**: CEDB recommended. Service to Main Gate House GH-1 transformer.
- **C07 (CUP1-N to TX-W3)**: CEDB recommended. Service to Warehouse W-3 transformer.

## Cost Summary Table
Detailed direct costs, labor hours, and total project cost roll-ups are provided in the accompanying conveyance_study.xlsx workbook.

## Findings in Government-Furnished Documents
1. **Area Cost Factor (ACF)**: Government Estimate Template applies an Area Cost Factor of 1.16 on Line 2. In accordance with UFS 3-701-01 paragraph 4-1.1 and RFP Section 01 11 00 paragraph 3.1, location factors must not be applied to bottom-up estimates prepared with local wage determinations and local supplier quotes. An ACF of 1.0 was applied.
2. **Wage Determination Modification**: Attachment J-3 includes Wage Determination CA20260022 Modification 2. In accordance with 29 CFR 1.6(c)(2)(ii)(A) and RFP paragraph 2.1, Modification 5 (issued August 6, 2026, >10 days prior to bid opening) is legally effective and was utilized for labor costing.
